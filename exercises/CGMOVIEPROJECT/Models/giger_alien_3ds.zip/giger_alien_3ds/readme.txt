This contains the 3ds project for a alien model.


The model has 2042 tris.


contact info:
www.jerryartist.com