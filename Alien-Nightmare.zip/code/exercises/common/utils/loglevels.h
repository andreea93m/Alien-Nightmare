/*
 * loglevels.h
 *
 *  Created on: 14.02.2011
 *      Author: sam
 */

#pragma once

#define LOG_LEVEL_DEBUG 4
#define LOG_LEVEL_INFO  3
#define LOG_LEVEL_WARN  2
#define LOG_LEVEL_ERROR 1
