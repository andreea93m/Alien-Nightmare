#!/bin/sh
export PATH=$PATH:/home/andreea/Downloads/Alien-Nightmare/build/bin:/usr/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/andreea/Downloads/Alien-Nightmare/build/lib:/usr/lib/x86_64-linux-gnu:/home/andreea/Downloads/Alien-Nightmare/build/lib
CGMOVIEPROJECT $*
#read -p "Press any key to continue"
